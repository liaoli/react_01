# react-devtools 安装

## 在线安装

- 有条件的直接打开 https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi 点击添加至Chrome

## 离线安装

- 1 git clone https://github.com/facebook/react-devtools.git
- 2 cd react-devtools
- 3 yarn 或者 npm i
- 4 编译生成Chrome浏览器插件：npm run build:extension:chrome
  - 插件目录：./shells/chrome/build/unpacked
- 说明：可以通过以上步骤自行安装，也可以直接拿到文件夹中的 unpacked目录 直接使用

---

- 5 打开Chrome输入 chrome://extensions/ 进入扩展程序设置页面
- 6 开启 开发者模式
- 7 加载已解压的扩展程序 选择第4步的unpacked目录， 确认安装即可
